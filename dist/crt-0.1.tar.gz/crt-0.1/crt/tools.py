import os


def get_all_directories(path):
    files = os.listdir(path)
    return files
